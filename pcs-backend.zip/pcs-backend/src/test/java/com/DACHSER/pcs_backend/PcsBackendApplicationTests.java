package com.DACHSER.pcs_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
